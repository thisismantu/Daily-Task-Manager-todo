<?php $__env->startSection('content'); ?>
<div class="row g-0">

    <div class="col-lg-6">
        <div class="card-body p-4 p-sm-5">
            <h5 class="card-title">Sign In</h5>
            <p class="card-text mb-5">Manage IT Daily Task System!</p>
            <form class="form-body" method="post" action="<?php echo e(Route('login')); ?>">
                <?php echo csrf_field(); ?>
                <div class="row g-3">
                    <div class="col-12">
                        <div class="ms-auto position-relative">
                            <div
                                class="position-absolute top-50 translate-middle-y search-icon px-3">
                                <i class="bi bi-envelope-fill"></i>
                            </div>
                            <input type="email" class="form-control radius-30 ps-5"
                                id="login-username" name="email" value="<?php echo e(old('email')); ?>" required
                                placeholder="Login Username *">
                        </div>
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-12">
                        <div class="ms-auto position-relative">
                            <div
                                class="position-absolute top-50 translate-middle-y search-icon px-3">
                                <i class="bi bi-lock-fill"></i>
                            </div>
                            <input type="password" class="form-control radius-30 ps-5" required
                                id="login-password" name="password" placeholder="Login Password *">
                        </div>
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-6">
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" name="remember"
                                value="1" <?php echo e(old('remember') ? 'checked' : ''); ?>

                                id="remember">
                            <label class="form-check-label" for="remember">Remember Me</label>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="d-grid">
                            <button type="submit" class="btn btn-primary radius-30">Sign
                                In</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('theme.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\php82\htdocs\Envogue\2025\task\resources\views/auth/login.blade.php ENDPATH**/ ?>