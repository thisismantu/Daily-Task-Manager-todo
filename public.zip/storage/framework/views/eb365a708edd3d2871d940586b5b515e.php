<tbody>
    <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr class="list list-<?php echo e($data->user->id); ?>" id="list-<?php echo e($data->user->id); ?>">
            <td> <?php echo e($loop->iteration); ?> </td>
            <td> <?php echo e($data->user->name); ?> </td>
            <td> <?php echo e($data->name); ?> </td>
            <td> <?php echo e($data->task_description); ?> </td>
            <td>
                <select class="select">
                    <option>Done</option>
                    <option>Pending</option>
                    <option>Inprocess</option>
                </select>
            </td>
            <td><?php echo e($data->created_at); ?></td>
            <td><?php echo e($data->updated_at); ?></td>
            <td>
                <button onclick="enableEdit(${data.id})" class="buton-rto"> <i class="bi bi-pencil-fill"></i> </button>
                <button onclick="viewRow(${data.id})" class="buton-update" title="view"> <i class="bi bi-eye-fill"></i>
                </button>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
<?php /**PATH C:\xampp\php82\htdocs\Envogue\2025\task\resources\views/components/task-list.blade.php ENDPATH**/ ?>