<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-8">
            <div class="box-fixed">
                <div class="scroll-container" style="position:relative;">
                    <div class="scroll-content" id="scroll-content">
                        <?php $__currentLoopData = $Users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <button onclick="changeuser('<?php echo e($user->name); ?>',<?php echo e($user->id); ?>)" class="btn-user"
                                id="btn-user-<?php echo e($user->id); ?>">
                                <?php echo e($user->name); ?> </button>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="box-fixed" style="margin-top:9px;">
                    <button class="scroll-button" id="left-btn" disabled style="margin-right:3px;"> <i
                            class="bi bi-chevron-left"></i> </button>
                    <button class="scroll-button" id="right-btn"><i class="bi bi-chevron-right"></i> </button>
                </div>
                <div class="button-addds" style="margin-left:5px;">
                    <a href="#" title="Add User" class="btrr btn" data-tooltip="Some info text" data-bs-toggle="modal"
                        data-bs-target="#exampleModaladd"
                        style="padding:0px 4px; color:#606060; background:#f0f0f0; border:1px solid #e2e2e2; border-radius:2px;">
                        <i class="bi bi-plus-circle"></i> </a>
                    <a href="#" title="edit Button" class="btrr btn"
                        style="padding: 0px 4px; color:#606060; background:#f0f0f0; border:non !important; border:1px solid #e2e2e2; border-radius:2px;">
                        <i class="bi bi-pencil-square"></i> </a>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <form method="post" action="<?php echo e(route('task.export')); ?>">
                <?php echo csrf_field(); ?>
                <div style=" display:flex; margin-top: 6px;">

                    <div>
                        <label style="font-size:15px;"> Date Filter: </label>
                        <input type="hidden" name="user_id" value="0" id="userIdsFilter" />
                        <input type="text" name="daterange"
                            style="background:#fafafa;  border: 1px solid #dedddd; border-radius: 3px; font-size: 15px; outline:none; padding:5px 10px; " />
                    </div>
                    <button type="submit" class="btn" style="padding:0px 9px; margin-left:6px; background:#f0f0f0;"> <i
                            class="bi bi-cloud-download"></i> </button>

                </div>
            </form>
        </div>

        <div class="row">
            <div class="col-md-12">
                <div class="table-status-detial" style=" margin-top:5px;">
                    <div class="table-responsive-box" style="overflow-y:auto; height:600px;">
                        <table class="table mt-2" style="width:100%" id="data-table">
                            <thead>
                                <?php if (isset($component)) { $__componentOriginal477a3352b1511a2886e2a53617b15ccc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal477a3352b1511a2886e2a53617b15ccc = $attributes; } ?>
<?php $component = App\View\Components\AddTaskForm::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('add-task-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AddTaskForm::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal477a3352b1511a2886e2a53617b15ccc)): ?>
<?php $attributes = $__attributesOriginal477a3352b1511a2886e2a53617b15ccc; ?>
<?php unset($__attributesOriginal477a3352b1511a2886e2a53617b15ccc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal477a3352b1511a2886e2a53617b15ccc)): ?>
<?php $component = $__componentOriginal477a3352b1511a2886e2a53617b15ccc; ?>
<?php unset($__componentOriginal477a3352b1511a2886e2a53617b15ccc); ?>
<?php endif; ?>
                                <tr>
                                    <th style="background:#f4f4f4;">&nbsp; </th>
                                    <th width="120" style="background:#f4f4f4;"> User </th>
                                    <th width="200" style="background:#f4f4f4;"> Task </th>
                                    <th width="360" style="background:#f4f4f4;"> Description </th>
                                    <th width="100" style="background:#f4f4f4;"> Status </th>
                                    <th style="background:#f4f4f4;"> Create Date </th>
                                    <th style="background:#f4f4f4;"> Modify Date </th>
                                    <th width="130px;" style="background:#f4f4f4;"> Action </th>
                                </tr>
                            </thead>
                            <tbody id="taskResponse">
                                <tr>
                                    <td colspan="8" class="text-center"><?php echo e(__('Loading Data ...')); ?></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php if (isset($component)) { $__componentOriginal6d8832c5e4efb806a762a36384303232 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6d8832c5e4efb806a762a36384303232 = $attributes; } ?>
<?php $component = App\View\Components\AddUserModal::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('add-user-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AddUserModal::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6d8832c5e4efb806a762a36384303232)): ?>
<?php $attributes = $__attributesOriginal6d8832c5e4efb806a762a36384303232; ?>
<?php unset($__attributesOriginal6d8832c5e4efb806a762a36384303232); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6d8832c5e4efb806a762a36384303232)): ?>
<?php $component = $__componentOriginal6d8832c5e4efb806a762a36384303232; ?>
<?php unset($__componentOriginal6d8832c5e4efb806a762a36384303232); ?>
<?php endif; ?>
    <?php $__env->startPush('script'); ?>
        <script>
            function changeuser(name, uid) {
                const inputField = document.getElementById('inputField');
                inputField.value = name;
                // $(".list").show();
                // $(".list").hide();
                // $(".list-" + uid).show();
                $('#name').prop('disabled', false);
                $('#task_description').prop('disabled', false);
                $('#submitTask').prop('disabled', false);
                $("#user_id").val(uid);
                $(".btn-user").removeClass('active');
                $("#btn-user-" + uid).addClass('active');
                $("#userIdsFilter").val(uid);



                callTaskList(uid);
            }

            $(document).ready(function() {
                callTaskList(0);
            });

            function callTaskList(user_id) {
                $.ajax({
                    url: "<?php echo e(route('task.index')); ?>",
                    method: 'GET',
                    data: {
                        user_id: user_id
                    },
                    success: function(response) {
                        $('#taskResponse').html(response);
                    },
                    error: function(xhr, status, error) {
                        $('#taskResponse').text('An error occurred: ' + error);
                        console.error(xhr.responseText);
                    }
                });
            }


            // function callTaskListUsingDate(startDate, endDate) {
            //     $.ajax({
            //         url: "<?php echo e(route('task.index')); ?>",
            //         method: 'GET',
            //         data: {
            //             user_id: user_id
            //         },
            //         success: function(response) {
            //             $('#taskResponse').html(response);
            //         },
            //         error: function(xhr, status, error) {
            //             $('#taskResponse').text('An error occurred: ' + error);
            //             console.error(xhr.responseText);
            //         }
            //     });
            // }

            function callUserList(user_id) {
                $.ajax({
                    url: "<?php echo e(route('users-master.index')); ?>",
                    method: 'GET',
                    data: {
                        user_id: user_id
                    },
                    success: function(response) {
                        $('#scroll-content').html(response);
                    },
                    error: function(xhr, status, error) {
                        $('#scroll-content').text('An error occurred: ' + error);
                        console.error(xhr.responseText);
                    }
                });
            }
        </script>
        <script>
            function enableEdit(id, taskurl) {
                // Correct string interpolation
                getTask(id, taskurl);
                $("#task_name_" + id).focus();
                $("#task_description_" + id).focus();
                // $("#btn-edit-" + id).html(
                //     `<button id="btn-save-" onclick="editTask(${id});"  class="buton-rto"> <i class="bi bi-floppy-fill"></i></button>`
                // );
                $("#status_" + id).prop('disabled', false);
                $("#btn-edit-" + id)
                    .attr("id", "btn-save-" + id)
                    .attr("onclick", "editTask(" + id + ");")
                    .html(`<i class="bi bi-floppy-fill"></i>`);
            }

            function editTask(id) {
                let updatedTaskName = $("#details-" + id).val();
                let updatedTaskDescription = $("#task_description-" + id).val();
                let status = $("#status_" + id).val();
                $.ajax({
                    url: $("#edit-task-" + id).attr("action"),
                    method: "PUT",
                    data: {
                        _token: "<?php echo e(csrf_token()); ?>",
                        id: id,
                        name: updatedTaskName,
                        task_description: updatedTaskDescription,
                        status: status
                    },
                    success: function(response) {
                        const task_get_url = "<?php echo e(url('task/')); ?>/" + id;
                        //         $("#btn-edit-" + id).html(`<button id="btn-edit-${id}"
                //     onclick="enableEdit(${id},'${task_get_url}');"
                //     class="buton-rto"> <i class="bi bi-pencil-fill"></i>
                // </button>`);

                        $("#btn-save-" + id)
                            .attr("id", "btn-edit-" + id)
                            .attr("onclick", "enableEdit(" + id + ",'" + task_get_url + "');")
                            .html(`<i class="bi bi-pencil-fill"></i>`);
                        flasher.success('Task updated successfully!');
                        $("#status_" + id).prop('disabled', true);
                        $("#details-" + id).hide();
                        $("#task_description-" + id).hide();
                        $("#task_name_" + id).text(updatedTaskName);
                        $("#task_description_" + id).text(updatedTaskDescription);
                        $("#task_name_" + id).find("button").remove();
                        // window.location = "<?php echo e(route('task.index')); ?>";
                    },
                    error: function(xhr, status, error) {
                        flasher.error('An error occurred while updating the task.');
                        console.error(xhr.responseText);
                    }
                });
            }

            function getTask(id, task_get_url) {
                $.ajax({
                    url: task_get_url,
                    method: "GET",
                    success: function(response) {
                        $("#task_name_" + response.id).html(
                            `<textarea id="details-${id}" class="inputarea">${response.name}</textarea>`);
                        $("#task_description_" + id).html(
                            `<textarea id="task_description-${response.id}" class="inputarea">${response.task_description}</textarea>`
                        );

                    },
                    error: function(xhr, status, error) {
                        flasher.error('An error occurred while getting the task.');
                        console.error(xhr.responseText);
                    }
                });



            }

            function viewGrid(id) {

                $("#list-"+id).addClass("bg-light");
            }
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('theme.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\php82\htdocs\Envogue\2025\task\resources\views/theme/task/list.blade.php ENDPATH**/ ?>