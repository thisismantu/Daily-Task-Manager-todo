<?php $__currentLoopData = $Users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <button onclick="changeuser('<?php echo e($user->name); ?>',<?php echo e($user->id); ?>)">
        <?php echo e($user->name); ?> </button>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\xampp\php82\htdocs\Envogue\2025\task\resources\views/theme/users/userlist.blade.php ENDPATH**/ ?>