<?php if(count($tasks) > 0): ?>
    <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <form method="post" id="edit-task-<?php echo e($data->id); ?>" action="<?php echo e(route('task.update', $data->id)); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <tr class="list list-<?php echo e($data->id); ?>" id="list-<?php echo e($data->id); ?>">
                <td> <?php echo e($loop->iteration); ?> </td>
                <td> <?php echo e($data->user->name); ?> </td>
                <td id="task_name_<?php echo e($data->id); ?>"> <?php echo e($data->name); ?> </td>
                <td id="task_description_<?php echo e($data->id); ?>"><?php echo e($data->task_description); ?> </td>
                <td>
                    <select class="select" disabled id="status_<?php echo e($data->id); ?>" name="status_<?php echo e($data->id); ?>">
                        <option value="DONE" <?php echo e($data->status === 'DONE' ? 'selected' : ''); ?>>Done</option>
                        <option value="PENDING" <?php echo e($data->status === 'PENDING' ? 'selected' : ''); ?>>Pending</option>
                        <option value="IN-PROCESS" <?php echo e($data->status === 'IN-PROCESS' ? 'selected' : ''); ?>>In Process
                        </option>
                    </select>
                </td>
                <td><?php echo e($data->created_at); ?></td>
                <td><?php echo e($data->updated_at); ?></td>
                <td>
                    <button id="btn-edit-<?php echo e($data->id); ?>"
                        onclick="enableEdit(<?php echo e($data->id); ?>,'<?php echo e(route('task.show', $data->id)); ?>');"
                        class="buton-rto btn-edit-<?php echo e($data->id); ?>"> <i class="bi bi-pencil-fill"></i>
                    </button>
                    <button onclick="viewGrid(<?php echo e($data->id); ?>)" class="buton-update" title="view"> <i
                            class="bi bi-eye-fill"></i>
                    </button>
                </td>
            </tr>
        </form>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
    <tr class="list">
        <td colspan="8" class="text-center"><?php echo e(__('No Task found')); ?></td>
    </tr>
<?php endif; ?>

<?php /**PATH C:\xampp\php82\htdocs\Envogue\2025\task\resources\views/theme/task/task-list.blade.php ENDPATH**/ ?>