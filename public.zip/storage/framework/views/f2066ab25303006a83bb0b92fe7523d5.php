<!doctype html>
<html lang="en" class="minimal-theme">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" href="assets/images/favicon-32x32.png" type="image/png" />

<!------- Bootstrap CSS ------->

<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" rel="stylesheet" />
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/icons.css')); ?>" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/icons/font/bootstrap-icons.min.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/datepicker/css/daterangepicker.css')); ?>" />	
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/style.css')); ?>" />

<!---- Google Fonts ----> 

<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500&amp;display=swap" rel="stylesheet">

<!---- loader ---->

<style> 

#myDivboxes { display:none; }
#myDivboxes2 { display:none; }

</style>


</head>
<body>

<div class="modal fade" id="exampleModaladd" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
   <div class="modal-dialog">
        <div class="modal-content">
        <div class="modal-header headderbox-bg">
            <h5 class="modal-title" id="exampleModalLabel" style="font-size:15px;">Add User Button  </h5>
            <button type="button" class="btn-close model-close-btn" data-bs-dismiss="modal" aria-label="Close" ></button>
        </div>
        <div class="modal-body body-padding">
        <div class="boxsquare-fild">
            <form action="" method="post">
            <div class="row">	
            <div class="col-md-10">
                <div class="form-group mb-3">
                <input type="text" placeholder="Enter Your User Name" class="form-control">  
            </div>	
            </div>   
                <div class="col-md-2">
                    <div class="boxflex"> 
                        <button class="btn btn-primary Butoon-btn" style="padding:5px 13px;"> Save </button>     
                    </div>
                   </div> 
                 </div>  
                </form>  
              </div>
           </div>
        </div>
    </div>
</div>

<!----- Start Wrapper ------>

<div class="container">
          <div class="row"> 
             <div class="col-md-8">
               <div class="box-fixed">
                <div class="scroll-container" style="position:relative;">
                <div class="scroll-content" id="scroll-content">
                    <?php $__currentLoopData = $Users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <button onclick="changeuser('<?php echo e($user->name); ?>',<?php echo e($user->id); ?>)"> <?php echo e($user->name); ?> </button>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>		
                </div> 
                <div class="box-fixed" style="margin-top:9px;">  
                  <button class="scroll-button" id="left-btn" disabled style="margin-right:3px;"> <i class="bi bi-chevron-left"></i> </button> 
                  <button class="scroll-button" id="right-btn"><i class="bi bi-chevron-right"></i> </button>
                </div> 
                <div class="button-addds" style="margin-left:5px;">
                      <a href="#" title="Add User" class="btrr btn" data-tooltip="Some info text" data-bs-toggle="modal" data-bs-target="#exampleModaladd" style="padding:0px 4px; color:#606060; background:#f0f0f0; border:1px solid #e2e2e2; border-radius:2px;"> <i class="bi bi-plus-circle"></i> </a>	
                      <a href="#" title="edit Button" class="btrr btn" style="padding: 0px 4px; color:#606060; background:#f0f0f0; border:non !important; border:1px solid #e2e2e2; border-radius:2px;"> <i class="bi bi-pencil-square"></i> </a>
                </div>	
                </div> 
                </div>	
                <div class="col-md-4"> 
                <div style=" display:flex; margin-top: 6px;">
                <div> 	
                <label style="font-size:15px;">  From Date/To Date  </label>
                <input type="text" name="daterange" value="01/01/2018 - 01/15/2018" style="background:#fafafa;  border: 1px solid #dedddd; border-radius: 3px; font-size: 15px; outline:none; padding:5px 10px; " />	
                </div>
                <button class="btn" style="padding:0px 9px; margin-left:6px; background:#f0f0f0;"> <i class="bi bi-cloud-download"></i> </button>	
               </div>
          </div>
                
        <div class="row">
             <div class="col-md-12"> 
                 <div class="table-status-detial" style=" margin-top:5px;"> 
                    <div class="table-responsive-box" style="overflow-y:auto; height:600px;">
                          <table class="table mt-2" style="width:100%" id="data-table"> 
                            <thead> 
                              <tr>
                               <form action="<?php echo e(route('task.store')); ?>" method="POST">  
                                    <?php echo csrf_field(); ?>
                                    <th> <input type="hidden" placeholder="user_id" name="user_id" id="user_id" class="form-control input-table">  </th>
                                    <th> <input type="text" placeholder="" id="inputField" class="form-control input-table" value="Raj" disabled style="background:#007bff; color:#FFF; border-bottom:none; border-radius:4px !important;" readonly>  </th>
                                    <th> <input type="text" name="name"  placeholder="Enter Your User Task" class="form-control input-table">  </th> 
                                    <th> <input type="text" name="task_description" placeholder="Enter Your Discription" class="form-control input-table" >  </th>
                                    <th> <button type="submit" style="border:1px solid #e5dbdb; border-radius:2px;"> Save </button>  </th>  
                                    </th>
                             </form> 
                            </tr> 
                             <tr>
                                <th style="background:#f4f4f4;">&nbsp; </th>
                                <th width="120" style="background:#f4f4f4;"> User	 </th>
                                <th width="200" style="background:#f4f4f4;"> Task	 </th>	
                                <th width="360" style="background:#f4f4f4;"> Description	 </th>
                                <th width="100" style="background:#f4f4f4;"> Status </th>
                                <th style="background:#f4f4f4;"> Create Date </th>
                                <th style="background:#f4f4f4;"> Modify Date </th>
                                <th width="130px;" style="background:#f4f4f4;"> Action </th>
                              </tr>
                                  </thead> 
                                        <tbody> 
                                              <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr class="list list-<?php echo e($data->user->id); ?>" id="list-<?php echo e($data->user->id); ?>">
                                                <td> <?php echo e($loop->iteration); ?> </td>
                                                <td> <?php echo e($data->user->name); ?> </td>
                                                <td> <?php echo e($data->name); ?> </td>
                                                <td> <?php echo e($data->task_description); ?> </td>
                                                <td>
                                                    <select class="select">
                                                        <option>Done</option> 
                                                        <option>Pending</option>
                                                        <option>Inprocess</option>
                                                    </select> 
                                                </td>
                                                <td><?php echo e($data->created_at); ?></td>
                                                <td><?php echo e($data->updated_at); ?></td>
                                                <td>
                                                    <button onclick="enableEdit(${data.id})" class="buton-rto"> <i class="bi bi-pencil-fill"></i> </button>
                                                    <button onclick="viewRow(${data.id})" class="buton-update" title="view"> <i class="bi bi-eye-fill"></i> </button>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                     </tbody>
                                 </table>
                             </div>
                         </div>  
                  </div>
             </div>
        </div>

<!-- Bootstrap bundle JS -->

<script src="<?php echo e(asset('assets/js/bootstrap.bundle.min.js')); ?>"></script>

<!--plugins-->

<script type="text/javascript" src="<?php echo e(asset('assets/js/jquery.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/datepicker/js/datepicker-latest_moment.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/datepicker/js/daterangepicker.min.js')); ?>"></script>
	
<script>
$(function() {
  $('input[name="daterange"]').daterangepicker({
    opens: 'left'
  }, function(start, end, label) {
    console.log("A new date selection was made: " + start.format('YYYY-MM-DD') + ' to ' + end.format('YYYY-MM-DD'));
  });
});
</script>	
<script>

    const scrollContent = document.getElementById('scroll-content');
    const leftBtn = document.getElementById('left-btn');
    const rightBtn = document.getElementById('right-btn');
    const containerWidth = document.querySelector('.scroll-container').offsetWidth;
    const scrollStep = containerWidth / 2;
    let scrollPosition = 0;
    const tableBody = document.querySelector('#data-table tbody');
    const tableData = <?php echo $Users; ?>;

    let activeName = null; // Track the active name for filtering
    const inputField = document.getElementById('inputField'); // Reference to the outer input field
    const user_id = document.getElementById('user_id'); // Reference to the outer input field

    const descriptionField = document.getElementById('taskDescription'); // Reference to the task description field
    const submitButton = document.getElementById('submitBtn'); // Reference to submit button
    const formContainer = document.getElementById('form-container'); // Reference to the form container

    // Populate buttons and handle click events
    const uniqueNames = [...new Set(tableData.map(data => data.name))]; // Get unique names

    // Update scroll buttons state
    function updateButtons() {
        leftBtn.disabled = scrollPosition === 0;
        rightBtn.disabled = scrollPosition >= scrollContent.scrollWidth - containerWidth;
    }

    leftBtn.addEventListener('click', () => {
        scrollPosition = Math.max(scrollPosition - scrollStep, 0);
        scrollContent.style.transform = `translateX(-${scrollPosition}px)`;
        updateButtons();
    });

    rightBtn.addEventListener('click', () => {
        scrollPosition = Math.min(scrollPosition + scrollStep, scrollContent.scrollWidth - containerWidth);
        scrollContent.style.transform = `translateX(-${scrollPosition}px)`;
        updateButtons();
    });

    // Populate the table with filtered data
    function populateTable() {
        const filteredData = activeName
            ? tableData.filter(data => data.name === activeName)
            : tableData;

        tableBody.innerHTML = filteredData.map(data => {
            return `
                <tr id="row-${data.id}">
                    <td>${data.id}</td>
                    <td>${data.name}</td>
                    <td>${data.details}</td>
                    <td>${data.details}</td>
                    <td>
                        <select class="select" >
                            <option>Done</option> 
                            <option>Pending</option>
                            <option>Inprocess</option>
                        </select> 
                    </td>
                    <td>10-01-2025</td>
                    <td>10-01-2025</td>
                    <td>
                        <button onclick="enableEdit(${data.id})" class="buton-rto"> <i class="bi bi-pencil-fill"></i> </button>
                        <button onclick="viewRow(${data.id})" class="buton-update" title="view"> <i class="bi bi-eye-fill"></i> </button>
                    </td>
                </tr>
            `;
        }).join('');
    }

    // View row data without the modal
    function viewRow(id) {
        const data = tableData.find(item => item.id === id);
        const row = document.getElementById(`row-${id}`);
        // Replace the content of the row with read-only values
        row.innerHTML = `
            <td>${data.id}</td>
            <td>${data.name}</td>
            <td>${data.details}</td>
            <td>${data.details}</td>
            <td>
                <select class="select" disabled>
                    <option>Done</option> 
                    <option>Pending</option>
                    <option>Inprocess</option>
                </select> 
            </td>
            <td>10-01-2025</td>
            <td>10-01-2025</td>
            <td>
                <button onclick="enableEdit(${data.id})" class="buton-rto"> <i class="bi bi-pencil-fill"></i> </button>
                <button onclick="viewRow(${data.id})" class="buton-update" title="view"> <i class="bi bi-eye-fill"></i> </button>
            </td>
        `;
    }

    // Enable editing for a specific row
    function enableEdit(id) {
        const data = tableData.find(item => item.id === id);
        const row = document.getElementById(`row-${id}`);
        row.innerHTML = `
            <td>${data.id}</td>
            <td>${data.name}</td>
            <td><textarea id="details-${id}" class="inputarea">${data.details}</textarea></td>
            <td><textarea id="details-${id}-second" class="inputarea">${data.detailsSecond || ''}</textarea></td>
            <td>
                <select class="select" id="status-${id}">
                    <option ${data.status === "Done" ? "selected" : ""}>Done</option>
                    <option ${data.status === "Pending" ? "selected" : ""}>Pending</option>
                    <option ${data.status === "Inprocess" ? "selected" : ""}>Inprocess</option>
                </select> 
            </td>
            <td> 10-01-2025 </td>
            <td> 10-01-2025 </td>
            <td>
                <button onclick="saveRow(${id})" class="buton-rto" title="save"><i class="bi bi-floppy"></i></button>
                <button onclick="cancelEdit(${id})" class="buton-cancel"> <i class="bi bi-x"></i> </button>
            </td>
        `;
    }

    // Save changes to the row

    function saveRow(id) {
        const details = document.getElementById(`details-${id}`).value;
        const detailsSecond = document.getElementById(`details-${id}-second`) ? document.getElementById(`details-${id}-second`).value : ''; // Handle second details field
        const status = document.getElementById(`status-${id}`).value;
        // Find the data for the row being edited
        const data = tableData.find(item => item.id === id);
        // Update the table data with the new values
        data.details = details;
        data.detailsSecond = detailsSecond;
        data.status = status;
        // Optional: Update dates if needed, for now it remains static
        data.date1 = "10-01-2025"; // You can update this dynamically if necessary
        data.date2 = "10-01-2025"; // Similarly, update the second date if needed
        // After saving, refresh the table to reflect the changes
        populateTable();
    }

    // Cancel editing and revert to the original data
    function cancelEdit(id) {
        // Simply repopulate the table to revert the row back to its original state
        populateTable();
    }

    // Form submit action (for task description)
    submitButton.addEventListener('click', () => {
        const taskDescription = descriptionField.value; // Get the value from the task description input field
        if (taskDescription.trim()) {
            // Find the corresponding data for the selected name
            const data = tableData.find(item => item.name === activeName);
            if (data) {
                // Add the task description to the data
                data.details = taskDescription; // Update the details field with the new task description

                // Refresh the table to show the updated description
                populateTable();
                
                // Clear the task description fieldW
                descriptionField.value = '';
                formContainer.style.display = 'none'; // Hide the form after submission
            }
        } else {
            alert('Please enter a task description.');
        }
    });

    populateTable(); //Show all rows by default
    updateButtons();

</script>

<script>
    function changeuser(name,uid) {
        const inputField = document.getElementById('inputField');
            inputField.value = name;
            $(".list").show();
            $(".list").hide();
            $(".list-"+uid).show();
         }
</script>










</body>
</html><?php /**PATH C:\xampp\php82\htdocs\Nootbook\resources\views/task-app.blade.php ENDPATH**/ ?>